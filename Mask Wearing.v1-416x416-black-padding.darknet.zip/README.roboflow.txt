
Mask Wearing - v1 416x416-black-padding
==============================

This dataset was exported via roboflow.ai on May 25, 2020 at 7:20 AM GMT

It includes 149 images.
People are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit (black edges))

No image augmentation techniques were applied.


